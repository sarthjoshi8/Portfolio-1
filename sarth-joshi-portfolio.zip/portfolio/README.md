# Sarth Joshi — Portfolio

A React + Vite portfolio built around a "systems status page" concept — nav styled
as API routes, resume metrics shown as live stat chips, dark UI with a red/green
accent system pulled from your photo.

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Build for deployment

```bash
npm run build
```

This outputs a static `dist/` folder you can deploy to Vercel, Netlify, GitHub Pages,
or any static host.

## Adding your intro video

The hero photo card is already wired to support a video toggle — it's just switched
off until you add a file:

1. Drop your video at `src/assets/sarth-intro.mp4` (keep it under ~10MB for fast load —
   compress with HandBrake or `ffmpeg -i in.mp4 -vcodec h264 -crf 28 sarth-intro.mp4`
   if it's larger)
2. Open `src/components/Hero.jsx`
3. Uncomment the `import sarthVideo from '../assets/sarth-intro.mp4'` line
4. Set `const hasVideo = false` to `const hasVideo = true`
5. Uncomment `<source src={sarthVideo} type="video/mp4" />`

A "▶ video" toggle button will then appear on the photo card, letting visitors switch
between your photo and video.

## Project structure

```
src/
  components/   — one file per section (Hero, Projects, Skills, ...)
  hooks/         — useReveal.js, the scroll-in-view animation hook
  assets/        — your photo (and video, once added)
  index.css      — all design tokens + styles
  App.jsx        — composes the page
```
