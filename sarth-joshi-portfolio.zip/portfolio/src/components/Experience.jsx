import Section from './Section'

export default function Experience() {
  return (
    <Section id="experience" title="Experience" route="/experience">
      <div className="exp-card">
        <div className="exp-top">
          <div className="exp-role">
            Android Application Development Intern · <span className="exp-org">RedBytes Pvt. Ltd.</span>
          </div>
          <div className="exp-date">Jun 2025 – Jul 2025</div>
        </div>
        <p className="exp-desc">
          Designed and built a production-grade Android app in Kotlin using MVVM architecture
          on a live client project — Jetpack components, Git version control, and Agile
          sprints alongside senior engineers.
        </p>
      </div>
    </Section>
  )
}
