import Section from './Section'

const projects = [
  {
    name: 'AI Resume Analyzer',
    link: 'https://github.com/sarthjoshi8/AI-Resumer-Analyzer',
    desc: 'AI-powered ATS scoring tool using Gemini 1.5 Flash — 0–100 ATS score, keyword gap analysis, and AI-rewritten bullet points. Async PDF/DOCX parsing with a custom rule-based scorer running in parallel, fully Dockerized.',
    tags: ['FastAPI', 'Gemini 1.5 Flash', 'React.js', 'Docker'],
    metric: '0–100 ATS scoring, dual-engine analysis',
  },
  {
    name: 'RideShare',
    link: 'https://github.com/sarthjoshi8/RideShare-App',
    desc: 'End-to-end Android carpooling app with MVVM + Hilt DI. Live GPS tracking via Google Maps, Haversine fare estimation, Firebase OTP auth, Razorpay payments, and FCM push notifications.',
    tags: ['Kotlin', 'Hilt', 'Firebase', 'Razorpay'],
    metric: 'Full booking flow in under 30 seconds',
  },
  {
    name: 'Shop-On',
    link: 'https://github.com/sarthjoshi8/Shop-On',
    desc: 'AR shopping app built for HackOn with Amazon 2022 — ARCore-powered virtual try-ons with size validation, fitment checks, and colour-theme sync through the camera. Firebase catalog + Retrofit REST client.',
    tags: ['Kotlin', 'ARCore', 'Firebase', 'Retrofit'],
    metric: 'HackOn with Amazon 2022 — live demo',
  },
  {
    name: 'Distributed URL Shortener',
    link: 'https://github.com/sarthjoshi8/Distributed-URL-Shortner',
    desc: 'Horizontally scalable shortener with Base62 encoding, Redis LRU cache, async analytics via Redis Streams, a Lua-scripted sliding-window rate limiter, and 2-instance Nginx load balancing.',
    tags: ['Node.js', 'Redis', 'PostgreSQL', 'Nginx'],
    metric: '95%+ cache hit rate, sub-5ms redirects, 10K users @ 0 errors',
  },
  {
    name: 'Real-Time Stock Screener',
    link: 'https://github.com/sarthjoshi8/StockScreener',
    desc: 'Bloomberg-inspired dashboard with a pure-Python RSI, MACD, EMA and Bollinger Bands engine. Multi-filter screener across 40 stocks via asyncio, real-time WebSocket price feed, PostgreSQL + Redis P&L tracking.',
    tags: ['FastAPI', 'WebSocket', 'Redux Toolkit', 'Redis'],
    metric: '40 stocks screened concurrently, live feed',
  },
]

export default function Projects() {
  return (
    <Section id="projects" title="Projects" route="/projects">
      <div className="proj-grid">
        {projects.map((p) => (
          <div className="proj-card" key={p.name}>
            <div className="proj-top">
              <div className="proj-name">{p.name}</div>
              <a className="proj-link" href={p.link} target="_blank" rel="noopener noreferrer">repo ↗</a>
            </div>
            <p className="proj-desc">{p.desc}</p>
            <div className="tags">
              {p.tags.map((t) => <span className="tag" key={t}>{t}</span>)}
            </div>
            <div className="proj-metric">{p.metric}</div>
          </div>
        ))}
      </div>
    </Section>
  )
}
