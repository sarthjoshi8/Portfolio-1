export default function Footer() {
  return (
    <footer>
      © 2026 Sarth Joshi — built with Space Grotesk, Inter &amp; JetBrains Mono
    </footer>
  )
}
