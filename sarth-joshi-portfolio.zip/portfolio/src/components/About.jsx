import Section from './Section'

export default function About() {
  return (
    <Section id="about" title="About" route="/about">
      <p className="about-text">
        I'm a Computer Science student at <b>VIT Vellore</b>, currently sitting at an 8.60
        CGPA, with a habit of finishing what I start — five production-grade projects, an
        Android internship, and an AIR 601 on VITEEE to get here. I move comfortably across
        the stack: <b>FastAPI and Express on the backend, React and Next.js on the front,
        Kotlin for Android</b>, and lately a lot of Google Gemini for anything that needs a
        brain. Outside of code, I help run VIT's Entrepreneurship Cell, coordinating
        1,000+ attendee conferences and mentoring juniors on startup ideation.
      </p>
    </Section>
  )
}
