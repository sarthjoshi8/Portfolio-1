import Section from './Section'

const items = [
  {
    date: '2023',
    title: 'Winner — Binary Battles',
    desc: 'VIT IEEE CS Central Hackathon, 500+ participants.',
  },
  {
    date: '2024',
    title: 'Finalist — Reverse Coding & Yantra 2024',
    desc: 'Competitive programming rounds; also 2nd Runner-Up, Pygame GameDev Competition (Gravitas 2024).',
  },
  {
    date: '2023',
    title: 'VITEEE — AIR 601',
    desc: "VIT's engineering entrance exam.",
  },
  {
    date: '2022-23',
    title: 'National Level Science Talent Exam',
    desc: 'AIR 5 overall, AIR 1 in Chemistry.',
  },
]

export default function Achievements() {
  return (
    <Section id="achievements" title="Achievements" route="/achievements">
      <div className="log">
        {items.map((it) => (
          <div className="log-row" key={it.title}>
            <div className="log-date mono">{it.date}</div>
            <div>
              <div className="log-title">{it.title}</div>
              <div className="log-desc">{it.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  )
}
