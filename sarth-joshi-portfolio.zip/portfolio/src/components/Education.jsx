import Section from './Section'

export default function Education() {
  return (
    <Section id="education" title="Education" route="/education">
      <div className="log">
        <div className="log-row">
          <div className="log-date mono">2023–now</div>
          <div>
            <div className="log-title">B.Tech, Computer Science &amp; Engineering — VIT Vellore</div>
            <div className="log-desc">CGPA 8.60 / 10.0</div>
          </div>
        </div>
        <div className="log-row">
          <div className="log-date mono">2021–22</div>
          <div>
            <div className="log-title">Class XII (Science) — Deogiri College, Chhatrapati Sambhajinagar</div>
            <div className="log-desc">91.50%</div>
          </div>
        </div>
      </div>
    </Section>
  )
}
