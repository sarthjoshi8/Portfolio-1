import { useState } from 'react'
import sarthPhoto from '../assets/sarth.jpg'

// To add your intro video later:
// 1. Drop the file at src/assets/sarth-intro.mp4
// 2. Uncomment the import + video block below
// 3. That's it — the ONLINE tag becomes a toggle between photo and video
// import sarthVideo from '../assets/sarth-intro.mp4'

export default function Hero() {
  const [showVideo, setShowVideo] = useState(false)
  const hasVideo = false // flip to true once sarth-intro.mp4 is added

  return (
    <div className="wrap hero">
      <div className="hero-grid">
        <div>
          <div className="eyebrow">B.Tech CSE, VIT Vellore &middot; Chhatrapati Sambhajinagar, IN</div>
          <h1>Sarth <span>Joshi</span></h1>
          <p className="role">
            Full-stack &amp; Android developer who likes systems that don't fall over —{' '}
            <b>Redis caches, load balancers, and Kotlin apps</b> — with a growing habit of
            wiring Gemini into all of it.
          </p>
          <div className="hero-ctas">
            <a className="btn btn-solid" href="#projects">View projects →</a>
            <a className="btn btn-ghost" href="#contact">Get in touch</a>
            <a className="btn btn-ghost" href="https://github.com/sarthjoshi8" target="_blank" rel="noopener noreferrer">GitHub ↗</a>
          </div>
          <div className="metrics">
            <div className="metric">
              <div className="num">8.60<small>/10</small></div>
              <div className="lbl">CGPA · VIT Vellore</div>
            </div>
            <div className="metric">
              <div className="num">10K<small>+ users</small></div>
              <div className="lbl">Load tested, 0 errors</div>
            </div>
            <div className="metric">
              <div className="num">5<small> shipped</small></div>
              <div className="lbl">Full production builds</div>
            </div>
          </div>
        </div>

        <div className="photo-card">
          <span className="photo-tag">
            <span className="dot static"></span>
            {showVideo ? 'PLAYING' : 'ONLINE'}
          </span>

          {hasVideo && (
            <button className="photo-toggle" onClick={() => setShowVideo(v => !v)}>
              {showVideo ? '◧ photo' : '▶ video'}
            </button>
          )}

          {showVideo && hasVideo ? (
            <video autoPlay loop muted playsInline>
              {/* <source src={sarthVideo} type="video/mp4" /> */}
            </video>
          ) : (
            <img src={sarthPhoto} alt="Portrait of Sarth Joshi wearing headphones at a laptop" />
          )}
        </div>
      </div>
    </div>
  )
}
