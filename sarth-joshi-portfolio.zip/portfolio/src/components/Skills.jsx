import Section from './Section'

const groups = [
  {
    label: 'Languages',
    items: ['Python', 'Java', 'C', 'C++', 'Kotlin', 'JavaScript (ES6+)', 'HTML5', 'CSS3'],
  },
  {
    label: 'Frameworks',
    items: ['React.js', 'Node.js', 'Express.js', 'FastAPI', 'Flask', 'Next.js 14', 'Redux Toolkit', 'TailwindCSS'],
  },
  {
    label: 'Databases & Cloud',
    items: ['MongoDB', 'PostgreSQL', 'MySQL', 'Firebase', 'Redis', 'AWS', 'Azure', 'Docker', 'Nginx', 'Linux'],
  },
  {
    label: 'Mobile & AI',
    items: ['Android (MVVM)', 'Jetpack Compose', 'ARCore', 'Maps SDK', 'Gemini AI', 'Prompt Engineering'],
  },
]

export default function Skills() {
  return (
    <Section id="skills" title="Skills" route="/skills">
      <div className="skills-grid">
        {groups.map((g) => (
          <div className="skill-group" key={g.label}>
            <div className="lbl">{g.label}</div>
            <div className="skill-tags">
              {g.items.map((i) => <span className="skill-tag" key={i}>{i}</span>)}
            </div>
          </div>
        ))}
      </div>
    </Section>
  )
}
