import Section from './Section'

export default function Contact() {
  return (
    <Section id="contact" title="Contact" route="/contact" verb="POST">
      <div className="contact-box">
        <div className="contact-head">
          <div className="dots"><span></span><span></span><span></span></div>
          <span>reach-out.sh</span>
        </div>
        <div className="contact-body">
          <div className="contact-cmd">$ curl -X POST <span className="path">/contact</span> --data "hello, sarth"</div>
          <div className="contact-links">
            <a className="contact-link" href="mailto:joshisarth8yt@gmail.com">✉ joshisarth8yt@gmail.com</a>
            <a className="contact-link" href="tel:+917350350254">☎ +91 73503 50254</a>
            <a className="contact-link" href="https://linkedin.com/in/sarthjoshi" target="_blank" rel="noopener noreferrer">in/sarthjoshi ↗</a>
            <a className="contact-link" href="https://github.com/sarthjoshi8" target="_blank" rel="noopener noreferrer">github/sarthjoshi8 ↗</a>
          </div>
        </div>
      </div>
    </Section>
  )
}
