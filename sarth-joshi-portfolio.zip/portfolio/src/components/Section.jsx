import useReveal from '../hooks/useReveal'

export default function Section({ id, title, route, verb = 'GET', children }) {
  const [ref, visible] = useReveal()
  return (
    <section id={id} ref={ref} className={`reveal ${visible ? 'in' : ''}`}>
      <div className="wrap">
        <div className="sec-head">
          <h2 className="sec-title">{title}</h2>
          <span className="sec-route mono">
            <span className={`verb ${verb === 'POST' ? 'post' : ''}`}>{verb}</span> {route}
          </span>
        </div>
        {children}
      </div>
    </section>
  )
}
