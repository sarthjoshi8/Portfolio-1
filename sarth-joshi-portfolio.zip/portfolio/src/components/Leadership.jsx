import Section from './Section'

export default function Leadership() {
  return (
    <Section id="leadership" title="Leadership" route="/leadership">
      <div className="exp-card">
        <div className="exp-top">
          <div className="exp-role">
            Senior Core Member · <span className="exp-org">Entrepreneurship Cell, VIT Vellore</span>
          </div>
          <div className="exp-date">Apr 2024 – Present</div>
        </div>
        <p className="exp-desc">
          Spearheaded E'Summit 25 and Innoventures — VIT's flagship entrepreneurship
          conferences, 1,000+ attendees run by a 30-member team. Mentored 20+ junior members
          on startup ideation and onboarded 5 external sponsor partnerships.
        </p>
      </div>
    </Section>
  )
}
