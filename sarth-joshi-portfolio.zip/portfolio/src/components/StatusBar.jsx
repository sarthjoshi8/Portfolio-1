export default function StatusBar() {
  return (
    <div className="statusbar">
      <div className="statusbar-inner">
        <div className="status-left">
          <span className="dot"></span>
          <span>sarthjoshi.dev — all systems operational</span>
        </div>
        <nav className="routes">
          <a href="#about"><span className="verb">GET</span>/about</a>
          <a href="#experience"><span className="verb">GET</span>/experience</a>
          <a href="#projects"><span className="verb">GET</span>/projects</a>
          <a href="#skills"><span className="verb">GET</span>/skills</a>
          <a href="#contact"><span className="verb post">POST</span>/contact</a>
        </nav>
      </div>
    </div>
  )
}
